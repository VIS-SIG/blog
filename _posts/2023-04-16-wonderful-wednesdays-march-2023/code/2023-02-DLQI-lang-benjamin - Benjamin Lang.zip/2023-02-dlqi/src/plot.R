### Load packages --------------------------------------------------------------
here::i_am("src/plot.R")
library(here)
library(ggplot2)
library(readxl)
library(dplyr)
library(colorspace)
library(RBesT)

### Read data ------------------------------------------------------------------
# Based on Table 1 from the underlying publication we retrieved
# - mean and sd
# - sample size N per trial
# - information whether it was in adults or mixed (adults and children)
d <- read_excel(here("data", "DLQI.xlsx"), 
                col_types = c("text", rep("numeric", 3), "text"))
d <- d %>% 
  mutate(SE = SD / sqrt(N),
         Low68 = M - SE,
         Low95 = M - qnorm(1 - 0.05/2) * SE,
         Up68  = M + SE,
         Up95  = M + qnorm(1 - 0.05 / 2) * SE)
d$Study <- factor(d$Study, levels = paste("Study", 1:12), ordered = TRUE)

### MAP ------------------------------------------------------------------------
# In addition to individual trial data, we use the RBesT package to derive
# - standard meta-analysis mean
# - meta-analytic-predictive (MAP) prior that accounts for the uncertainty in
#   the population mean and the between-trial heterogeneity (see vignettes
#   of the package for more details) 
set.seed(1234)
gmap_d <- gMAP(cbind(M, SE) ~ 1 | Study, weights = N, data = d, 
               family = gaussian, beta.prior = cbind(0, 100 * mean(d$SD)), 
               tau.dist = "HalfNormal", 
               # since trials are mixed between adults and children, assume
               # large heterogeneity:
               tau.prior = cbind(0, mean(d$SD) / 2))
map_95 <- forest_plot(gmap_d, prob = 0.95)$data[c("theta_resp_pred", "theta_resp"), ]
map_68 <- forest_plot(gmap_d, prob = 0.68)$data[c("theta_resp_pred", "theta_resp"), ]

# Merge to d
d <- bind_rows(d, data.frame(Study = "Mean", M = map_95[2, 1], SD = NA, 
                             N = max(d$N, na.rm = TRUE), 
                             Population = "Meta", SE = map_95[2, 2], 
                             Low68 = map_68[2, 4], Low95 = map_95[2, 4], 
                             Up68 = map_68[2, 5], Up95 = map_95[2, 5]))

d <- bind_rows(d, data.frame(Study = "MAP",
                             M = map_95[1, 3], # map_95[1, 3] is the median, not mean
                             SD = NA, N = max(d$N, na.rm = TRUE), 
                             Population = "Meta", SE = NA,
                             Low68 = map_68[1, 4], Low95 = map_95[1, 4], 
                             Up68 = map_68[1, 5], Up95 = map_95[1, 5]))

d$Study <- factor(d$Study, levels = c("MAP", "Mean", paste("Study", 1:12)), 
                  ordered = TRUE)

### Plot summary measures ------------------------------------------------------
# Define cutoffs for severity of impact on QoL, including colors mapped to them
# Note: since we have the mean score (and not individual values), we use 
# [0, 2), [2, 5) etc. instead of discrete regions 0-1, 2-5 etc.
cutoffs <- c(0, 2, 6, 11, 21, 30)
cols <- rev(sequential_hcl(n = 5, palette = "Viridis"))

dlqi <- ggplot(data = d, aes(x = Study, y = M)) +
  ## Reference lines
  geom_hline(yintercept = cutoffs, color = "gray93", linewidth = 0.5) +
  ## Include error bars for studies
  #  95% CI
  geom_segment(aes(x = Study, xend = Study, y = Low95, yend = Up95, 
                   color = cut(M, cutoffs, right = FALSE)), 
               alpha = 0.25, linewidth = 2, lineend = "round") +
  #  68% CI
  geom_segment(aes(x = Study, xend = Study, y = Low68, yend = Up68, 
                   color = cut(M, cutoffs, right = FALSE)), alpha = 0.5,
               linewidth = 2, lineend = "round") +
  ## Include points for the mean
  #  Size of point depends proportional to sample size
  geom_point(mapping = aes(color = cut(M, cutoffs, right = FALSE), size = N), 
             alpha = 1) +
  scale_size(range = c(2, 5)) +
  scale_color_manual(breaks = levels(cut(d$M, cutoffs, right = FALSE)),
                     values = cols) +
  guides(alpha = "none", color = "none", shape = "none", fill = "none", 
         size = "none") +
  coord_flip() +
  geom_text(y = 1, x = 0.65, label = "no effect", color = cols[1], size = 3.6) +
  geom_text(y = 4, x = 0.65, label = "small effect", color = cols[2], size = 3.6) +
  geom_text(y = 8.5, x = 0.65, label = "moderate effect", color = cols[3], size = 3.6) +
  geom_text(y = 16, x = 0.65, label = "very large effect", color = cols[4], size = 3.6) +
  geom_text(y = 25.5, x = 0.65, label = "extremely large effect", color = cols[5], size = 3.6) +
  theme_classic() +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 30), breaks = cutoffs) +
  theme(axis.line.y = element_blank(),
        axis.line.x = element_line(linewidth = 0.8),
        axis.title.x = element_text(size = 14, hjust = 0.5, vjust = -1),
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
        axis.ticks = element_line(linewidth = 0.8),
        axis.ticks.y = element_blank(),
        axis.ticks.length = grid::unit(6, "pt"),
        plot.title = element_text(size = 19, hjust = 0, margin = margin(b = 15)),
        plot.caption = element_text(size = 10, hjust = 0, color = "gray50",
                                    margin = margin(t = 12)),
        plot.margin = margin(t = 5.5, r = 10, b = 5.5, l = 4.5)
        ) +
  labs(x = "", y = "Mean DLQI score", 
       title = "The majority of patients had a small to moderate effect on quality of life",
       caption = "Bars represent 68% and 95% confidence limits\nThe size of each point for the mean DLQI score is proportional to the study size\nMeta-analysis mean and Meta-Analytic-Predictive (MAP) prior were calculated with the R package RBesT assuming large heterogeneity")

k <- 2
ggsave(filename = here("results", "DLQI_summary.png"),
       plot = dlqi, device = "png",
       width = k * 7, height = k * 7 / 1.618,
       units = "in", dpi = 300)


### Plot individual data -------------------------------------------------------
# Emulate scenario where we have individual data by simulating data
# For sake of simplicity we just use a normal distribution, round down/up to get
# integer numbers and cap at 0 and 30, respectively
set.seed(1234)
d2 <- data.frame(Study = rep(d[1:12, ]$Study, d[1:12, ]$N),
                 DLQI  = c(
                   round(rnorm(n = d[[1, "N"]], mean = d[[1, "M"]], sd = d[[1, "SD"]]), 0),
                   round(rnorm(n = d[[2, "N"]], mean = d[[2, "M"]], sd = d[[2, "SD"]]), 0),
                   round(rnorm(n = d[[3, "N"]], mean = d[[3, "M"]], sd = d[[3, "SD"]]), 0),
                   round(rnorm(n = d[[4, "N"]], mean = d[[4, "M"]], sd = d[[4, "SD"]]), 0),
                   round(rnorm(n = d[[5, "N"]], mean = d[[5, "M"]], sd = d[[5, "SD"]]), 0),
                   round(rnorm(n = d[[6, "N"]], mean = d[[6, "M"]], sd = d[[6, "SD"]]), 0),
                   round(rnorm(n = d[[7, "N"]], mean = d[[7, "M"]], sd = d[[7, "SD"]]), 0),
                   round(rnorm(n = d[[8, "N"]], mean = d[[8, "M"]], sd = d[[8, "SD"]]), 0),
                   round(rnorm(n = d[[9, "N"]], mean = d[[9, "M"]], sd = d[[9, "SD"]]), 0),
                   round(rnorm(n = d[[10, "N"]], mean = d[[10, "M"]], sd = d[[10, "SD"]]), 0),
                   round(rnorm(n = d[[11, "N"]], mean = d[[11, "M"]], sd = d[[11, "SD"]]), 0),
                   round(rnorm(n = d[[12, "N"]], mean = d[[12, "M"]], sd = d[[12, "SD"]]), 0)
                 )) %>%
  mutate(DLQI = ifelse(DLQI > 30, 30, ifelse(DLQI < 0, 0, DLQI)))

ms <- d2 %>% group_by(Study) %>% summarize(M = mean(DLQI))
d2 <- left_join(d2, ms, by = "Study") %>%
  left_join(d[, c("Study", "N")], by = "Study")

dlqi2 <- ggplot(data = d2, aes(x = Study, y = DLQI)) +
  geom_hline(yintercept = cutoffs, color = "gray93", linewidth = 0.5) +
  geom_violin(aes(color = cut(M, cutoffs, right = FALSE))) + 
  stat_summary(fun = mean, geom = "point", shape = 18,
               mapping = aes(size = N, color = cut(M, cutoffs, right = FALSE))) +
  scale_size(range = c(2, 5)) +
  geom_jitter(aes(color = cut(M, cutoffs, right = FALSE)), 
              height = 0.1, width = 0.1, alpha = 0.1) + 
  scale_color_manual(breaks = levels(cut(d2$M, cutoffs, right = FALSE)),
                     values = cols) +
  guides(alpha = "none", color = "none", shape = "none", fill = "none", 
         size = "none") +
  coord_flip() +
  geom_text(y = 1, x = 0.65, label = "no effect", color = cols[1], size = 3.6) +
  geom_text(y = 4, x = 0.65, label = "small effect", color = cols[2], size = 3.6) +
  geom_text(y = 8.5, x = 0.65, label = "moderate effect", color = cols[3], size = 3.6) +
  geom_text(y = 16, x = 0.65, label = "very large effect", color = cols[4], size = 3.6) +
  geom_text(y = 25.5, x = 0.65, label = "extremely large effect", color = cols[5], size = 3.6) +
  theme_classic() +
  scale_y_continuous(expand = c(0, 0), breaks = cutoffs) +
  theme(axis.line.y = element_blank(),
        axis.line.x = element_line(linewidth = 0.8),
        axis.title.x = element_text(size = 14, hjust = 0.5, vjust = -1),
        axis.text.x = element_text(size = 12),
        axis.text.y = element_text(size = 12),
        axis.ticks = element_line(linewidth = 0.8),
        axis.ticks.y = element_blank(),
        axis.ticks.length = grid::unit(6, "pt"),
        plot.title = element_text(size = 19, hjust = 0, margin = margin(b = 15)),
        plot.caption = element_text(size = 10, hjust = 0, color = "gray50",
                                    margin = margin(t = 12)),
        plot.margin = margin(t = 5.5, r = 10, b = 5.5, l = 4.5)
  ) +
  labs(x = "", y = "DLQI score", 
       title = "The majority of patients had a small to moderate effect on quality of life",
       caption = "Points are jittered to handle overplotting.\nDiamonds correspond to the mean and their size is proportional to the respective study size")

k <- 2
ggsave(filename = here("results", "DLQI_individual.png"),
       plot = dlqi2, device = "png",
       width = k * 7, height = k * 7 / 1.3,
       units = "in", dpi = 300)
