library(tidyverse)
library(mice)
library(assertr)
library(GGally)
library(finalfit)
library(naniar)
library(ggpubr)
library(cowplot)
library(Rmisc)
library(directlabels)


#Clear environment
rm(list=ls())

#Colour scheme
Turquoise100 <- "#00a3e0"
Turquoise75 <- "#40bae8"
Turquoise50 <- "#7fd1ef"
Turquoise25 <- "#bfe8f7"
Blue100 <- "#005587"
Blue50 <- "#7FAAC3"
Green100 <- "#43b02a"
Green50 <- "#a1d794"
Purple100 <-"#830065"
Purple50 <- "#c17fb2"

#Set data and results areas up
sourcedata <- "C:/Users/q1062810/OneDrive - IQVIA/Wonderful Wednesday/Missing/sourcedata/"
outputdata <-"C:/Users/q1062810/OneDrive - IQVIA/Wonderful Wednesday/Missing/outputdata/"
tables <- "C:/Users/q1062810/OneDrive - IQVIA/Wonderful Wednesday/Missing/tables/"
figures <- "C:/Users/q1062810/OneDrive - IQVIA/Wonderful Wednesday/Missing/figures/"

setwd(sourcedata)
dat <- read_csv("missing_data.csv")

#make a dataset with just the pain vars and a flag denoting monotone missingness
dat_pain <- dat %>%
  dplyr::select(1:11) %>%
  mutate(monotone=
   ifelse(is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.7) & is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.6) & is.na(pain.7) & is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.5) & is.na(pain.6) & is.na(pain.7) & is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.4) & is.na(pain.5) & is.na(pain.6) & is.na(pain.7) & is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.3) & is.na(pain.4) & is.na(pain.5) & is.na(pain.6) & is.na(pain.7) & is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   ifelse(is.na(pain.2) & is.na(pain.3) & is.na(pain.4) & is.na(pain.5) & is.na(pain.6) & is.na(pain.7) & is.na(pain.8) & is.na(pain.9) & is.na(pain.10), 1,
   0)))))))))

dat_pain_long <- dat_pain %>%
  rename_with(~ gsub("pain.", "T_", .x, fixed = TRUE)) %>%
  mutate(subject = c(1:300)) %>%
  pivot_longer(c(-monotone, -subject), names_to = "timepoint", values_to = "AVAL") %>%
  mutate(Missing = ifelse(is.na(AVAL), "Missing", "Not Missing")) %>%
  dplyr::select(-AVAL) %>%
  pivot_wider(id_cols = c(subject, monotone), names_from = timepoint, values_from = Missing) %>%
  dplyr::select(-subject,-monotone, -T_0) %>%
  apply(2, table) %>% # tabulate response distributions
  as.data.frame() %>% #apply on the above line makes a matrix. This converts to a dataframe.
  mutate(missing = as.factor(c("Missing", "Not Missing"))) %>%
  pivot_longer(-missing, names_to = "timepoint", values_to = "frequency") 
dat_pain_long$timepoint <- substring(dat_pain_long$timepoint, 3)

levels(dat_pain_long$timepoint)
dat_pain_long$timepoint <- factor(dat_pain_long$timepoint, levels = c("10","9","8","7","6","5","4","3","2","1"))
levels(dat_pain_long$timepoint)


  Plot_Miss_Prop <- ggplot(data=dat_pain_long, mapping = aes(fill = missing, x=timepoint, y=frequency)) + #start with a ggplot statement
  geom_bar(aes(fill=factor(missing)),position="fill", stat="identity")+ #tell it you want a bar chart. position "fill" makes it a stacked bar chart
  scale_fill_manual(name = "Missing status",values=c(Turquoise100, Turquoise50), guide = guide_legend(reverse = TRUE)) + #set the colours. Reverse makes sure that the bars are 0-3 rather than 3-0
  theme_classic() + #just removes gridlines etc 
  ggtitle("Missing Data Distribution", subtitle = "Pain Assessment")+ 
  labs(y= "Proportion of missing data", x = "Visit") +
  scale_y_continuous(labels = scales::percent) + #makes the axis percent
  coord_flip() + #flips to a horizontal chart 
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=16),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="bottom")

#view plot
Plot_Miss_Prop
#Save plot
setwd(figures)
png(filename = paste(figures, '1.Missing data Distributions.png', sep=""),  width = 600, height = 450, units = "px", pointsize = 10,bg = "white")
Plot_Miss_Prop
dev.off()

dat_pain_wide <- dat_pain %>% 
                    rename_with(~ gsub("pain.", "Visit_", .x, fixed = TRUE)) %>%
                    dplyr::select(1:11)
dat_pain_wide_reset <- dat_pain_wide

Unordered_vismiss <- vis_miss(dat_pain_wide) 

Unordered_vismiss$data$variable <- factor(Unordered_vismiss$data$variable, levels = c("Visit_0", "Visit_1","Visit_2","Visit_3","Visit_4","Visit_5","Visit_6","Visit_7","Visit_8","Visit_9","Visit_10"))

Unordered_vismiss <- 
Unordered_vismiss + scale_x_discrete(name = , breaks=, labels= c("Visit_0" = "Baseline", "Visit_1" = "Visit 1","Visit_2" = "Visit 2","Visit_3" = "Visit 3","Visit_4" = "Visit 4","Visit_5" = "Visit 5","Visit_6" = "Visit 6","Visit_7" = "Visit 7","Visit_8" = "Visit 8","Visit_9" = "Visit 9","Visit_10" = "Visit 10"), limits=) +
  scale_fill_manual(name = "",values=c("white", Turquoise100), labels=c("", " represents missing observations")) +
  theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust=0.5)) +
  theme_minimal() + #just removes gridlines etc 
  ggtitle("Missing Data Timeseries", subtitle = "One row for each patient")+
  labs(y= "Patients") +
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=18),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="bottom") 

#view plot
Unordered_vismiss
#Save plot
setwd(figures)
png(filename = paste(figures, '2.Missing data Timeseries (unordered).png', sep=""),  width = 800, height = 450, units = "px", pointsize = 10,bg = "white")
Unordered_vismiss
dev.off()


dat_pain_wide <- cbind(dat_pain_wide, dat_pain$monotone) %>%
  rename(monotone = `dat_pain$monotone` ) %>%
  arrange(across(c(monotone, Visit_10:Visit_1)))

Ordered_vismiss <- vis_miss(dat_pain_wide %>% dplyr::select(1:11))

Ordered_vismiss$data$variable <- factor(Unordered_vismiss$data$variable, levels = c("Visit_0", "Visit_1","Visit_2","Visit_3","Visit_4","Visit_5","Visit_6","Visit_7","Visit_8","Visit_9","Visit_10"))

Ordered_vismiss <- 
  Ordered_vismiss + scale_x_discrete(name = , breaks=, labels= c("Visit_0" = "Baseline", "Visit_1" = "Visit 1","Visit_2" = "Visit 2","Visit_3" = "Visit 3","Visit_4" = "Visit 4","Visit_5" = "Visit 5","Visit_6" = "Visit 6","Visit_7" = "Visit 7","Visit_8" = "Visit 8","Visit_9" = "Visit 9","Visit_10" = "Visit 10"), limits=) +
  scale_fill_manual(name = "",values=c("white", Turquoise100), labels=c("", " represents missing observations")) +
  theme(axis.text.x = element_text(angle = 0, vjust = 0.5, hjust=0.5)) +
  theme_minimal() + #just removes gridlines etc 
  ggtitle("Missing Data Timeseries", subtitle = "One row for each patient")+
  labs(y= "Patients") +
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=18),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="bottom") 

#view plot
Ordered_vismiss
#Save plot
setwd(figures)
png(filename = paste(figures, '3.Missing data Timeseries (ordered).png', sep=""),  width = 800, height = 450, units = "px", pointsize = 10,bg = "white")
Ordered_vismiss
dev.off()

upset <- gg_miss_upset(dat_pain_wide %>% dplyr::select(1:11), 
              nintersects = 8,
              matrix.color = Turquoise50,
              main.bar.color = Turquoise100,
              sets.bar.color = Turquoise50,
              mainbar.y.label = "Number of patients \n with missingness pattern",
              sets.x.label = "Frequency of missing \n data at each visit",
              shade.color = Turquoise25,
              text.scale = 3,
              point.size=10)

#view plot
upset
#Save plot
setwd(figures)
png(filename = paste(figures, '4.Missing data Upset.png', sep=""),  width = 1200, height = 900, units = "px", pointsize = 10,bg = "white")
upset
dev.off()


explanatory = c("age", "bmi", 
                "gender")
dependent = c("Visit_6","Visit_7","Visit_8","Visit_9","Visit_10")

age <- dat$age
bmi <- dat$bmi
gender <- dat$gender

Explore_MAR <- cbind(age, bmi, gender, dat_pain_wide_reset)  %>% 
  missing_pairs(dependent, explanatory, position = "fill")

Explore_MAR_selection <- Explore_MAR$plots[c(6:8,14:16, 22:24, 30:32,38:40)]

# loop version 2
for (i in 1:length(Explore_MAR_selection)) {
  Explore_MAR_selection[[i]]$labels$y <- ""
  Explore_MAR_selection[[i]]$labels$x <- ""
  Explore_MAR_selection[[i]]$plot_env$miss <- ""
}

Explore_MAR_Plot <- ggarrange(plotlist=Explore_MAR_selection, ncol = 3, nrow = 5, common.legend = TRUE, legend = "none", labels = c("Age", "BMI", "Gender"), vjust = 0.5, hjust = c(-5,-5,-2)) +
  theme_classic()


#view plot
Explore_MAR_Plot
#Save plot
setwd(figures)
png(filename = paste(figures, '5. MAR Exploration Plot.png', sep=""),  width = 800, height = 450, units = "px", pointsize = 10,bg = "white")
Explore_MAR_Plot
dev.off()

#### treatment differences

dat_long <- dat %>%
  rename_with(~ gsub("pain.", "Visit_", .x, fixed = TRUE)) %>%
  select(1:11, 25) %>%
  mutate(subject = c(1:300)) %>%
  pivot_longer(c(-subject,-trt), names_to = "AVISIT", values_to = "AVAL")
dat_long$AVISIT <- as.numeric(substring(dat_long$AVISIT, 7))
dat_long_summary <- summarySE(dat_long, measurevar="AVAL", groupvars=c("trt", "AVISIT"),na.rm = TRUE)

#pd <- position_dodge(0.1)
not_imputed <- ggplot(dat_long_summary, aes(x=AVISIT, y=AVAL, colour=trt, group=trt)) + 
  geom_line(position=pd, size=1.5) +
  #geom_point(position=pd, size=3, shape=21, fill="white") + # 21 is filled circle
  #geom_errorbar(aes(ymin=AVAL-ci, ymax=AVAL+ci), colour="black", width=.1, position=pd) +
  xlab("Visit Number") +
  ylab("Pain Assessment Score") +
  scale_colour_manual(name="Treatment Arm",   
                      breaks=c("pbo", "act"),
                      labels=c("Placebo", "Active Treatment"),
                      values=c(Green100,Blue100,Green100, Blue100)) +                    # Use darker colors, lightness=40
  ggtitle("Non-Imputed Data", subtitle= "Shows Pain Reduction from Visit 2") +
  expand_limits(y=0, x=12) +                        # Expand y range
  scale_y_continuous(breaks=0:60*5) +         # Set tick every 4
  scale_x_continuous(breaks=0:10) +
  theme_classic() +
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=18),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="none") +
  geom_text(aes(x = 10, y = 14, label = "Placebo", color = Green100, hjust=-0.1)) + 
  geom_text(aes(x = 10, y = 8, label = "Treatment", color = Blue100, hjust=-0.1)) +
  theme(panel.grid.major.y = element_line())



#view plot
not_imputed
#Save plot
setwd(figures)
png(filename = paste(figures, '6. Non-imputed efficacy.png', sep=""),  width = 800, height = 450, units = "px", pointsize = 10,bg = "white")
not_imputed
dev.off()


explanatory = "age"
dependent = c("Visit_1","Visit_2","Visit_3","Visit_4","Visit_5","Visit_6","Visit_7","Visit_8","Visit_9","Visit_10")
dat_imputed <- cbind(age, bmi, gender, dat_pain_wide_reset)

dat_imputed %>% 
  select(dependent, explanatory) %>% 
  missing_predictorMatrix(
    drop_from_imputed = c("obstruct.factor", "mort_5yr")
  ) -> predM

dat_imputed <- dat_imputed %>% 
  select(dependent, explanatory) %>% 
  # Usually run imputation with 10 imputed sets, 4 here for demonstration
  mice(m = 10, predictorMatrix = predM)

dat_imputed <- complete(dat_imputed) 

trt <- dat$trt
Visit_0 <- dat_pain_wide_reset$Visit_0
dat_imputed <-cbind(Visit_0,dat_imputed, trt )

dat_imputed_long <- dat_imputed %>%
  mutate(subject = c(1:300)) %>%
  pivot_longer(c(Visit_0:Visit_10), names_to = "AVISIT", values_to = "AVAL")

dat_imputed_long$AVISIT <- as.numeric(substring(dat_imputed_long$AVISIT, 7))
  
dat_imputed_long_summary <- summarySE(dat_imputed_long, measurevar="AVAL", groupvars=c("trt", "AVISIT"))
pd <- position_dodge(0.1)
# Multiple line plot

imputed <- ggplot(dat_imputed_long_summary, aes(x=AVISIT, y=AVAL, colour=trt, group=trt)) + 
  geom_line(position=pd, size=1.5) +
  #geom_point(position=pd, size=3, shape=21, fill="white") + # 21 is filled circle
  #geom_errorbar(aes(ymin=AVAL-ci, ymax=AVAL+ci), colour="black", width=.1, position=pd) +
  xlab("Visit Number") +
  ylab("Pain Assessment Score") +
  scale_colour_manual(name="Treatment Arm",   
                   breaks=c("pbo", "act"),
                   labels=c("Placebo", "Active Treatment"),
                   values=c(Green100,Blue100,Green100, Blue100)) +                    # Use darker colors, lightness=40
  ggtitle("Imputed Data", subtitle= "Also shows Pain Reduction from Visit 2") +
  expand_limits(y=0, x=12) +                        # Expand y range
  scale_y_continuous(breaks=0:60*5) +         # Set tick every 4
  scale_x_continuous(breaks=0:10) +
  theme_classic() +
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=18),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="none") +
  geom_text(aes(x = 10, y = 14, label = "Placebo", color = Green100, hjust=-0.1)) + 
  geom_text(aes(x = 10, y = 8, label = "Treatment", color = Blue100, hjust=-0.1)) +
  theme(panel.grid.major.y = element_line())
#view plot
imputed
#Save plot
setwd(figures)
png(filename = paste(figures, '7. Imputed efficacy.png', sep=""),  width = 800, height = 450, units = "px", pointsize = 10,bg = "white")
imputed
dev.off()


####plot change

dat_long_change <- dat_long %>%
  arrange(subject, AVISIT) %>%
  group_by(subject) %>%
  mutate(CHG = AVAL - AVAL[1L]) %>%
  ungroup()

dat_imputed_long_change <- dat_imputed_long %>%
  arrange(subject, AVISIT) %>%
  group_by(subject) %>%
  mutate(CHG = AVAL - AVAL[1L]) %>%
  ungroup()

dat_long_change_summary <- summarySE(dat_long_change, measurevar="CHG", groupvars=c("trt", "AVISIT"),na.rm = TRUE)
dat_imputed_long_change_summary <- summarySE(dat_imputed_long_change, measurevar="CHG", groupvars=c("trt", "AVISIT"),na.rm = TRUE)

ggplot(dat_long_change_summary, aes(x=AVISIT, y=CHG, colour=trt, group=trt)) + 
  geom_line(position=pd, size=1.5) +
  #geom_point(position=pd, size=3, shape=21, fill="white") + # 21 is filled circle
  #geom_errorbar(aes(ymin=CHG-ci, ymax=CHG+ci), colour="black", width=.1, position=pd) +
  xlab("Visit Number") +
  ylab("Pain Assessment Score") +
  scale_colour_manual(name="Treatment Arm",   
                      breaks=c("pbo", "act"),
                      labels=c("Placebo", "Active Treatment"),
                      values=c(Green100,Blue100,Green100, Blue100)) +                    # Use darker colors, lightness=40
  ggtitle("Non-Imputed Data", subtitle= "") +
  expand_limits(y=0, x=12) +                        # Expand y range
  scale_y_continuous(breaks=-50:10*5) +         # Set tick every 4
  scale_x_continuous(breaks=1:10) +
  theme_classic() +
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=18),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="none") +
  geom_text(aes(x = 10, y = 14, label = "Placebo", color = Green100, hjust=-0.1)) + 
  geom_text(aes(x = 10, y = 8, label = "Treatment", color = Blue100, hjust=-0.1)) +
  theme(panel.grid.major.y = element_line())

ggplot(dat_imputed_long_change_summary, aes(x=AVISIT, y=CHG, colour=trt, group=trt)) + 
  geom_line(position=pd, size=1.5) +
  #geom_point(position=pd, size=3, shape=21, fill="white") + # 21 is filled circle
  #geom_errorbar(aes(ymin=CHG-ci, ymax=CHG+ci), colour="black", width=.1, position=pd) +
  xlab("Visit Number") +
  ylab("Pain Assessment Score") +
  scale_colour_manual(name="Treatment Arm",   
                      breaks=c("pbo", "act"),
                      labels=c("Placebo", "Active Treatment"),
                      values=c(Green100,Blue100,Green100, Blue100)) +                    # Use darker colors, lightness=40
  ggtitle("Imputed Data", subtitle= "") +
  expand_limits(y=0, x=12) +                        # Expand y range
  scale_y_continuous(breaks=-50:10*5) +         # Set tick every 4
  scale_x_continuous(breaks=1:10) +
  theme_classic() +
  theme(panel.background = element_blank(), axis.line = element_blank(),
        axis.text=element_text(size=16),
        axis.title=element_text(size=18),
        legend.text=element_text(size=16),
        legend.title=element_text(size=16),
        plot.title = element_text(size=22, face="bold"),
        plot.subtitle = element_text(size=16, face="bold"),
        legend.position="none") +
  geom_text(aes(x = 10, y = 14, label = "Placebo", color = Green100, hjust=-0.1)) + 
  geom_text(aes(x = 10, y = 8, label = "Treatment", color = Blue100, hjust=-0.1)) +
  theme(panel.grid.major.y = element_line())
